#define KAIMANA

#ifdef MOLEDCULE
	#define data_led 7
#endif

#ifdef KAIMANA
	#define data_led 23		
#endif

#define bright 50

#define punch_led 6
#define kick_led 6
#define alt_led 0
#define balltop_led 0
#define plate_led 8
#define controller_led 0

#define count_led 14

#define FIGHTSTICK						
/*
 EOF
*/